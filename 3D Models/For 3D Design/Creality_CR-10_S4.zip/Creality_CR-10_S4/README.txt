                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2565204
Creality CR-10 S4 by jdub1981 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Dimensionally accurate model created with Sketchup Make 2017.   Purpose of the model is to create a good starting point for others to use in creating their own mods.  Individual pieces may be printed from this model if needed.

The model was entirely drawn in Sketchup 2017 and I have done my best to convert it to something more usable by the community.

Sketchup files arent supported by Thingiverse so here is a direct link to the file on the Sketchup 3D Warehouse: https://3dwarehouse.sketchup.com/model/b6af4d45-69b9-4351-9cb3-a8e0c02c622c/Creality-CR-10-S4






# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/11/82/bd/e3/6d/Creality_CR-10_S4_XRAY2.PNG)

![Alt text](https://cdn.thingiverse.com/assets/84/59/a7/c7/36/Creality_CR-10_S4_XRAY.PNG)